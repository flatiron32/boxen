Install [reattach-to-user-namespace](https://github.com/ChrisJohnsen/tmux-MacOSX-pasteboard), notes and workarounds for accessing the Mac OS X pasteboard in tmux sessions..

## Usage
```puppet
include reattach_to_user_namespace
```

## Required Puppet Modules
* boxen
* homebrew

## Development
Write code. Run `script/cibuild` to test it. Check the `script` directory for other useful tools.

##Version Tag
`0.0.1`
